import React, {Component} from 'react';
import './library.css'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as libraryActions from "../../store/library/actions";
export default class library extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    render() {
      return <div className="component-library">
        
        <h1>-- Image Gallery --</h1>
        <div class="gallery">
        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2015/04/19/08/32/rose-729509__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2014/04/10/11/24/rose-320868__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2016/07/11/21/23/water-lily-1510707__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2015/08/13/20/06/flower-887443__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2017/07/25/01/22/cat-2536662__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2018/04/10/08/14/butterfly-3306655__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2012/09/08/21/51/flower-56414__340.jpg" alt="" />
        </div>

        <div class="box">
            <img src="https://cdn.pixabay.com/photo/2019/05/14/16/43/flower-4202825__340.jpg" alt="" />
        </div>
    </div>
      </div>;
    }
  }
// export default connect(
//     ({ library }) => ({ ...library }),
//     dispatch => bindActionCreators({ ...libraryActions }, dispatch)
//   )( library );